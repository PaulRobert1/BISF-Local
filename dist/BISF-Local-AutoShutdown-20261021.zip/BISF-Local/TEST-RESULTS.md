# Verification record

## Automatic operator sign-out and shutdown update - 2026-10-21

Base: uploaded AutoPermissions build `8d6c5b9ef1a966156f2498f906a4e75be95e3195`.
Successful applying Prepare now waits for the exact protected SYSTEM worker to
acknowledge readiness, releases its logger and apply lock, then requests normal
Windows sign-out from the original operator's interactive session. The existing
worker remains responsible for profile unload/deletion verification, final log
cleanup and shutdown. Configuration values and the XML schema are unchanged.

**142 focused tests passed, 0 failed:** entrypoint routing (15), full workflow
safety/results (45), existing finalization safety (36), acknowledgement and final
revalidation (31), and native session boundary decisions (15). These tests never
invoke a real Windows sign-out or shutdown. Native operations use test doubles;
the C# interop declarations also compile without calling their Windows APIs.

The full Pester run on PowerShell Core 7.5.4/Linux with Pester 5.7.1 reported
**348 passed / 31 failed / 379 total**, with no failed containers. All **57 added
tests pass**. The remaining 31 failing names are a multiset subset of the prior
55 platform failures: there are **no newly failing tests**. Twenty-four existing
finalization tests now pass because their Windows command signatures and registry
boundaries are correctly mocked in the test harness. Product checks were not
relaxed. The full suite is **not green** on this Linux host; the report includes
every remaining failing name and error:
[automatic-signout-20261021.json](docs/testing/automatic-signout-20261021.json).

Red/green checks reproduced missing automatic routing, session validation and
worker acknowledgement before implementation. Review also identified a worker
that could exit during final profile queries; a regression reproduced this and
the liveness check now follows those queries immediately before the session check
and sign-out request. An accepted task with failed readiness retains its state
and does not authorize sign-out. Pending reboot, another loaded profile,
configuration/identity changes, a stale or dead worker, failed cleanup and preview
modes continue preventing the corresponding sign-out/deletion/shutdown actions.

The rebuilt x64 console EXE retains `requireAdministrator`/`uiAccess=false` and
now describes automatic sign-out in its help. Manifest, packaged defaults, runtime
source audit and `git diff --check` passed. Consecutive launcher builds were
byte-identical. EXE SHA256:
`a797b809b83c864a074ffe7ece66b52b2802a07e43bd466a1d912c78561187d4`.

**Not run:** native Windows PowerShell 5.1, console/RDP sign-out on Windows Server
2025 or Windows 11, live UAC/ACL operations, actual SYSTEM-task lifetime, real
profile unload/deletion or physical/VM shutdown. Normal sign-out uses
`ExitWindowsEx(EWX_LOGOFF, planned application-maintenance reason)` and may be
blocked or canceled by applications. Acceptance rows remain NOT RUN; this report
does not claim a completed native master-image sealing cycle.

## Automatic installation permissions update - 2026-10-21

Base: supplied archive at commit `d457ab624d53a3dce6b9d8c20118cb3ea7ca42fe`.
This update adds automatic installation ACL initialization before normal Prepare
loads the main runtime, an administrator manifest in the EXE, and actionable ACL
error details. The supplied XML/XSD and cleanup/finalization behavior are unchanged.

Fresh development verification used PowerShell Core 7.5.4 on Ubuntu 24.04.3 LTS
with Pester 5.7.1. **65 focused tests passed, 0 failed**: installation policy and
repair decisions (21), real entry-script startup against harmless stub modules
(7), lifecycle/ACL diagnostics (19), and runtime source audit (18). New behavior
was exercised with failing tests before implementation. Windows ACL and native
hard-link-query boundaries are mocked; ordinary test filesystem operations are real.

The full original suite had **235 passed / 55 failed / 290 total** on this Linux
host. The updated suite had **267 passed / 55 failed / 322 total**, no failed
containers. The complete multiset of 55 failing test names is unchanged; all 32
added tests pass. This is **not a claim that the full Windows suite passed**.
Existing failures involve Windows-only commands, registry/WindowsIdentity APIs,
and Windows locked-file semantics. See
[the machine-readable result and all failing test names](docs/testing/automatic-permissions-20261021.json).

The rebuilt AMD64 PE32+ console launcher contains manifest resource type 24,
ID 1, with `requireAdministrator` and `uiAccess=false`. The resource regression
fails against the original EXE and passes against the rebuilt EXE. Consecutive
builds were byte-identical; imports remain the same 16 KERNEL32 functions.
The packaging/defaults checks and build-script syntax check passed.

EXE SHA256: `1de435a3836b643ed90a20dfa7eaf68adaa757ad001d45e737bb0b042727d782`.

Independent code review found and rechecked fixes for code read access, private
backup-file inheritance, private-directory propagation and null DACL handling.
No blockers remained in the reviewed scope. Actual Windows PowerShell 5.1,
desktop UAC, native ACL writes/PInvoke and master-image sealing **were not run**
for this update. Wine launcher execution was unavailable because Wine is absent.
The added Windows acceptance rows in ACCEPTANCE-TESTING.md remain NOT RUN.

## Latest continuation verification — 2026-10-15

Runtime commit `a26ca25a65596a33b428c02de466df35ee15bcec` passed the full
`Tests/Invoke-Tests.ps1` suite on GitHub's Windows Server 2025 runner,
Windows PowerShell 5.1 and Pester 5.7.1: **264 passed, 0 failed, 0 skipped**.
Run: https://github.com/PaulRobert1/BISF-Local/actions/runs/38737851224

The starting PR #2 head passed 232 tests. This continuation adds 32 cases,
including profile dependency boundaries and ambiguous provider results, changed
session state, staging trust/state prerequisites, new servicing-run detection,
Finalize preview, safe checkbox XML saves, configuration approval races and
Task Scheduler enumeration errors. Regression-only CI runs were observed failing
before fixes; see [REVIEW-2026-10-15.md](REVIEW-2026-10-15.md) for exact evidence.

XML/file operations use disposable Pester TestDrive data; the editor's locked-file
and atomic-replacement behavior is exercised on the Windows runner. Profile
removal, servicing, SYSTEM task execution, event clearing and shutdown remain
mocked. The real GUI and native ACL enforcement have not been accepted.
No operation was executed on SWCTXMASTER05. PR #1 is unchanged and PR #2 remains
open, unmerged and draft. The shipped XML/XSD and destructive defaults are unchanged.

All disposable Server 2025 and Windows 11 MCS acceptance rows in
[ACCEPTANCE-TESTING.md](ACCEPTANCE-TESTING.md) remain **NOT RUN**. Passing CI is
not production certification. Later documentation commits can advance the head;
verify the current head's Actions result before continuing.

## Earlier verification history

2026-10-12, Linux x86_64 development host.

- PowerShell 7.6.6, Pester 5.7.1: 130 tests passed, 0 failed.
- Actual suite entry point: `Tests/Invoke-Tests.ps1`.
- Runtime files parsed by PowerShell; default XML exercised against its XSD.
- Source audit checks for forbidden external execution, legacy mutations and binaries.
- Windows service, CIM, task and ACL effects are mocked in portable tests.
- Real XML/file logging, cleanup selection/deletion, and JSON state round trips exercised
  against disposable local test directories. No Windows master image was modified.

Not executed: Windows PowerShell 5.1, Server 2025/Windows 11 image lifecycle,
real Citrix VDA/WEM 2507 installations, Configuration Manager, Windows ACL enforcement,
actual SYSTEM startup task,
PVS/MCS provisioning or real shutdown. These require the Windows acceptance checklist
in README.md. This is development verification, not production certification.

Independent source review completed. All five actionable findings were addressed:
state-file trust checks before reads, ScheduledTasks Function discovery, default
empty-plan strict-mode behavior, post-shutdown logging order, and durable success
under combined failures. Regression tests were observed failing before fixes and
passing afterward. The reviewer did not re-review the fix pass; automated regression
verification was performed by the implementer.

PSScriptAnalyzer 1.24.0 PSUseCompatibleSyntax targeting Windows PowerShell 5.1:
no findings in the entry script or runtime modules. This checks syntax, not actual
Windows API behavior. Direct CLI execution on Linux returned exit code 1 with an
unsupported-host diagnostic and no image changes.

No minor review findings were deferred. Runtime tools and development dependencies
are outside the shipped archive. See IMPLEMENTATION-NOTES.md for decisions and limits.


Citrix extension verification: 37 additional tests cover XML/backward compatibility,
release checks, missing MCS component, WEM prerequisites, default/alternate cache
selection, local-path rejection, WEM cache exclusion from cleanup, WhatIf/Validate,
VDA stop/shutdown ordering, partial stop failure, recovery and the accepted-shutdown
boundary. A module-scope test exercises enabled VDA discovery under production strict
mode. Windows inventory, registry discovery and service-controller calls remain mocked.

The Citrix reviewer identified an unbounded Stop-Service wait; fixed using NoWait and
explicit bounded waits, with focused failing-then-passing regressions. The reviewer
rechecked the fix and reported no definite remaining issue. Their minor suggestion to
assert the current controller recovery path rather than the obsolete Start-Service call
was also applied. No review findings were deferred.

Version-independent update: all 130 tests pass. Tests cover older and newer version
strings, unknown resources, legacy Norskale host service discovery, absence of the
optional logon service, existing Windows eligibility checks and existing failure
recovery. No Citrix version comparison remains. Windows runtime and actual agent/OS
compatibility remain unverified.

## WEM cache diagnostics regression additions (2026-10-15)

The `fix/wem-cache-diagnostics-20261015` branch adds four read-only
WEM cache state tests and one integration test verifying that a missing cache
logs a warning in Validate mode without stopping services or requesting shutdown.
It also adds a GitHub Actions workflow using the `windows-2025` runner and
Windows PowerShell 5.1 with Pester 5.7.1.

The 2026-10-12 revision passed 130 portable Pester tests. The first updated
WEM-only branch passed **135/135 Pester tests** on Windows Server 2025 / Windows
PowerShell 5.1: https://github.com/PaulRobert1/BISF-Local/actions/runs/38701590882.
These Windows-hosted tests still mock Citrix agents and do not certify an MCS clone.

## Profile cleanup regression additions (2026-10-15)

An opt-in Cleanup.UserProfiles operation uses native Win32_UserProfile inventory
and Remove-CimInstance (wrapped for Pester) with protective SID/path guards.
Tests cover disabled-by-default legacy XML, explicit exclusions, operator and
built-in administrator protection, path boundaries, special/system identities,
loaded-profile and RefCount blockers, Validate/WhatIf immutability, and
per-SID pre-deletion revalidation against lifecycle/path changes.

**158/158 Pester tests passed, 0 failed, 0 skipped** on Windows Server 2025
with Windows PowerShell 5.1, GitHub Actions:
https://github.com/PaulRobert1/BISF-Local/actions/runs/38705010124.

Profile deletion in this CI run was simulated by mocks. No real profile was
deleted, no real Citrix agent was installed, and no MCS provisioning was tested.
Actual MCS master image integration and clone acceptance remain required.

## Windows 11 release-awareness tests (2026-10-15)

Platform inventory now recognizes Windows 11 21H2, 22H2, 23H2, 24H2,
25H2, 26H2, and the special 26H1 release, while checking the workstation
ProductType separately from Windows Server 2025 (shared 26100 build).
Unknown future client builds generate an explicit compatibility warning;
unknown future server builds remain blocked. Regression cases include
26H2's VDA CU compatibility guidance and negative OS candidates.

**169/169 Pester tests passed** (0 failed, 0 skipped) on Windows Server
2025 using Windows PowerShell 5.1:
https://github.com/PaulRobert1/BISF-Local/actions/runs/38726337356

Windows 11 is covered by portable mocked-OS unit tests on the Windows
Server 2025 GitHub runner. **No actual Windows 11 virtual machine or
Citrix single-session VDA was tested** by these checks. Verify MCS
provisioning, user-profile behavior, and Citrix support on an isolated
Windows 11 template before production rollout.

## Post-logoff operator sealing and maintenance (2026-10-15)

Stacked draft PR #2 adds read-only system-volume, pending reboot and
profile-management inventory; optional Microsoft Windows Servicing task
cleanup, current-user Recycle Bin cleanup and protected one-shot SYSTEM
operator-profile finalization after normal sign-out. All mutating
operations remain opt-in.

The tests are simulated with Pester mocks on the Windows Server 2025
runner: no real profile deletion, scheduled SYSTEM worker execution,
Windows component servicing, Recycle Bin deletion or shutdown is
performed by CI. **Even a passing CI run does not certify production
master-image safety.** A disposable MCS master and test catalog
acceptance is mandatory before enabling operator finalization.

Read-only `-Mode VerifyClone` was added to report OS build, VDA/MCS
components, WEM/cache state, domain join, disk space and profile-manager
services without mutating image state. Its output deliberately labels
broker registration, ICA logon, WEM synchronization, activation and
profile-container attachment as NotVerified until externally tested.
GitHub CI invokes the verification with mocked service/CIM responses,
not with a real Citrix session.

## Log hygiene configuration checkboxes (2026-10-15)

Added optional Windows Forms configuration editor Configure-BISF-LogCleanup.ps1,
optional LogCleanup XML flags (both false by default), late-stage cleanup,
and regression tests for preview isolation, fixed log scope, file matching,
deferred finalization and fail-closed shutdown boundaries.

Windows Server 2025 / Windows PowerShell 5.1 GitHub Actions Pester suite:
232 passed, 0 failed, 0 skipped for commit
81eef67be621a0d21ea267392b09c55d7dc07aac.
Run: https://github.com/PaulRobert1/BISF-Local/actions/runs/38732870070

The editor's source was syntax-checked, but the GUI has NOT been exercised
interactively. Provider operations were mocked: no production logs were
cleared, no administrator profile was removed, and no real SYSTEM
sign-out/shutdown cycle was tested. Production readiness is NOT established.

