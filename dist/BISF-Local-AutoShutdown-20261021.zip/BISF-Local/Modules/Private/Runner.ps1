# BIS-F Local, unofficial derivative. Modified 2026-10-12. GPL-3.0; see LICENSE.
function Get-BISFPlan {
    param($Config, [string]$Mode)
    $steps = New-Object 'System.Collections.Generic.List[object]'
    if ($Mode -eq 'Personalize') {
        $steps.Add([pscustomobject]@{Id='CloneGuard';Description='Verify prepared generation and clone identity'})
        if ($Config.ConfigurationManager.CloneTrustedRootKeyReset) { $steps.Add([pscustomobject]@{Id='CMCloneReset';Description='Reset Configuration Manager TrustedRootKey through CIM'}) }
        if ($Config.ConfigurationManager.PrepareIdentityReset -or $Config.ConfigurationManager.CloneTrustedRootKeyReset) { $steps.Add([pscustomobject]@{Id='CMStart';Description='Start Configuration Manager client'}) }
        $steps.Add([pscustomobject]@{Id='Complete';Description='Record successful clone personalization'})
    } else {
        if ($Config.Servicing.ComponentCleanup) {
            $steps.Add([pscustomobject]@{Id='Servicing';Description='Run built-in Windows Servicing component cleanup (no ResetBase)'})
        }
        foreach ($id in 'WindowsTemp','CurrentUserTemp') {
            if ($Config.Cleanup.$id) { $steps.Add([pscustomobject]@{Id=$id;Description="Remove old temporary files: $id"}) }
        }
        if ($Config.Cleanup.RecycleBin) { $steps.Add([pscustomobject]@{Id='RecycleBin';Description='Empty the Windows system-drive Recycle Bin'}) }
        if ($Config.Cleanup.UserProfiles) { $steps.Add([pscustomobject]@{Id='UserProfiles';Description='Remove inactive non-system local Windows user profiles through CIM'}) }
        if ($null -ne $Config.PSObject.Properties['Explorer'] -and ($Config.Explorer.RemoveQuickAccess -or $Config.Explorer.ClassicContextMenu)) {
            $steps.Add([pscustomobject]@{Id='ExplorerSettings';Description='Remove Quick Access/Home and enable classic context menus for Explorer users'})
        }
        if ($Config.ConfigurationManager.PrepareIdentityReset) { $steps.Add([pscustomobject]@{Id='CMPrepare';Description='Stop CcmExec and remove SMS client identity'}) }
        if ($Config.Personalization.Enabled -or $Config.ConfigurationManager.PrepareIdentityReset -or $Config.ConfigurationManager.CloneTrustedRootKeyReset) {
            $steps.Add([pscustomobject]@{Id='Lifecycle';Description='Record a preparation generation and optional startup task'})
        }
        if ($Config.LogCleanup.WindowsEventLogs -or $Config.LogCleanup.BISFLogs) {
            $steps.Add([pscustomobject]@{Id='LogCleanup';Description='Clear opted-in Windows Event Logs and/or BISF diagnostic logs at final shutdown'})
        }
        if ($Config.Citrix.VDA.Enabled -and $Config.Citrix.VDA.StopBeforeShutdown) { $steps.Add([pscustomobject]@{Id='VDAStop';Description='Stop Citrix Desktop Service immediately before shutdown; preserve startup type'}) }
        if ($Config.Finalization.RemoveOperatorProfile) {
            $steps.Add([pscustomobject]@{Id='OperatorFinalize';Description='Start SYSTEM profile cleanup, automatically sign out the operator, then shut down after final cleanup'})
        } elseif ($Config.FinalAction -eq 'Shutdown') {
            $steps.Add([pscustomobject]@{Id='Shutdown';Description='Request computer shutdown'})
        }
    }
    $steps.ToArray()
}
function Confirm-BISFOperation {
    param($Caller, [string]$Target, [string]$Action)
    $Caller.ShouldProcess($Target,$Action)
}
function Invoke-BISFLocal {
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true)][string]$ConfigPath,
        [Parameter(Mandatory=$true)][string]$ScriptRoot,
        [ValidateSet('Validate','Prepare','Personalize')][string]$Mode='Validate'
    )
    $results=New-Object 'System.Collections.Generic.List[object]'
    $logger=$null; $lock=$null; $state=$null; $previousCM=$null; $previousVDA=$null; $citrix=$null
    $exitCode=0; $errorMessage=$null; $applying=$false; $stateTouched=$false
    $completionTouched=$false; $journal=$null; $shutdownRequested=$false; $journalStatus=$null
    $profilePlan=$null; $operatorTarget=$null; $operatorSession=$null; $operatorSignOut=$null
    $currentStep='Preflight'
    try {
        $ScriptRoot=[IO.Path]::GetFullPath($ScriptRoot)
        $ConfigPath=Resolve-BISFPath $ConfigPath $ScriptRoot
        $hash=(Get-BISFFileHash -LiteralPath $ConfigPath).Hash
        $config=Read-BISFConfig $ConfigPath $ScriptRoot
        if ((Get-BISFFileHash -LiteralPath $ConfigPath).Hash -ne $hash) {
            throw 'Configuration changed while reading settings. Retry with a stable configuration.'
        }
        $inventory=Get-BISFInventory
        $plan=@(Get-BISFPlan $config $Mode)
        Test-BISFPreflight $config $Mode $plan $ScriptRoot $ConfigPath $inventory
        $citrix=Get-BISFCitrixReadiness $config $Mode
        $protected=@($ScriptRoot,$ConfigPath,(Join-Path $ScriptRoot 'state'),$config.Logging.Path)
        if ($null -ne $citrix.WEM) { $protected+=@($citrix.WEM.CachePath) }
        $statePath=Join-Path $ScriptRoot 'state/lifecycle.json'
        if ($Mode -ne 'Validate' -and -not $WhatIfPreference) { $lock=Enter-BISFLock }
        if ($Mode -eq 'Personalize') {
            $journalStatus=Get-BISFJournalStatus $ScriptRoot
            if ($journalStatus.PreparationPending) { throw 'Incomplete preparation journal found. Retry Prepare on the master and recapture.' }
            Test-BISFProtectedLocation $statePath
            $state=Read-BISFState $statePath
            if ($state.Status -ne 'Prepared') { throw 'Preparation did not complete successfully; refusing personalization.' }
            if ($state.ConfigHash -ne $hash) { throw 'Configuration changed since preparation. Prepare the master again with the intended configuration.' }
            Test-BISFCloneIdentity $state.Master $inventory.Identity
        }
        $logger=New-BISFLogger $config $Mode
        Write-BISFLog $logger Info Inventory ("OS={0}; Build={1}; Computer={2}; CcmExec={3}; Mode={4}" -f $inventory.Caption,$inventory.Build,$inventory.Identity.Name,$inventory.CMInstalled,$Mode)
        # More detailed platform identity is informational: it never changes
        # deletion, service, reboot, or Citrix version gating.
        if ($null -ne $inventory.PSObject.Properties['Version'] -and $null -ne $inventory.PSObject.Properties['ProductType']) {
            $platform=Get-BISFWindowsRelease $inventory
            $platformLevel=if ($platform.RequiresCompatibilityReview) { 'Warning' } else { 'Info' }
            Write-BISFLog $logger $platformLevel Platform ("Family={0}; Release={1}; Build={2}; RecognizedBuild={3}; ScriptEligible={4}. {5}" -f $platform.Family,$platform.Release,$platform.Build,$platform.RecognizedBuild,$platform.Eligible,$platform.Guidance)
        }
        if ($null -ne $citrix.VDA) { Write-Host "Citrix VDA: $($citrix.VDA.Version); MCS component: $($citrix.VDA.MachineIdentityService)." }
        if ($null -ne $citrix.VDA) { Write-BISFLog $logger Info CitrixVDA ("VDA=$($citrix.VDA.Version); MCS component=$($citrix.VDA.MachineIdentityService); Desktop Service=$($citrix.VDA.State), $($citrix.VDA.Startup)") }
        if ($null -ne $citrix.WEM) {
            # Older test doubles and callers may not expose the new diagnostics.
            $cacheStatus='Unknown'; $hostState='Unknown'; $cacheFiles='Unknown'
            if ($null -ne $citrix.WEM.PSObject.Properties['CacheStatus']) { $cacheStatus=[string]$citrix.WEM.CacheStatus }
            if ($null -ne $citrix.WEM.PSObject.Properties['HostState']) { $hostState=[string]$citrix.WEM.HostState }
            if ($null -ne $citrix.WEM.PSObject.Properties['LocalAgentCachePresent'] -and $null -ne $citrix.WEM.PSObject.Properties['LocalAgentDatabasePresent']) {
                $cacheFiles="LocalAgentCache.db=$($citrix.WEM.LocalAgentCachePresent), LocalAgentDatabase.db=$($citrix.WEM.LocalAgentDatabasePresent)"
            }
            $level='Info'
            $guidance='Cache file existence does not verify WEM synchronization. WEM may purge inherited databases on an MCS clone and rebuild its cache.'
            if ($cacheStatus -eq 'DirectoryMissing') {
                $level='Warning'
                $guidance='Cache directory is absent. Verify the WEM agent has synchronized and check its registration/connectivity on the master and a test clone. BIS-F does not create or refresh WEM cache.'
            } elseif ($cacheStatus -eq 'Incomplete') {
                $level='Warning'
                $guidance='One or both WEM database files are absent. Verify agent synchronization on the master and a test clone. BIS-F does not create or refresh WEM cache.'
            }
            if ($hostState -notin @('Running','Unknown')) {
                $level='Warning'
                $guidance+=" WEM host service state is $hostState; inspect agent health before image capture."
            }
            Write-BISFLog $logger $level CitrixWEM ("WEM=$($citrix.WEM.Version); hostState=$hostState; cache=$($citrix.WEM.CachePath); cacheStatus=$cacheStatus; $cacheFiles. $guidance")
        }
        if ($Mode -ne 'Personalize' -and $config.Finalization.RemoveOperatorProfile) {
            $currentStep='OperatorFinalize'
            $operatorTarget=Get-BISFOperatorSealTarget $config $ScriptRoot $ConfigPath -ProtectedPaths $protected
            if ($Mode -eq 'Prepare' -and -not $WhatIfPreference) {
                $operatorSession=Get-BISFOperatorSession -ExpectedSid $operatorTarget.SID
            }
            Write-BISFLog $logger Info OperatorFinalize ("Operator SID={0}; local profile={1}; automatic sign-out follows successful preparation and SYSTEM readiness; profile deletion follows unload." -f $operatorTarget.SID,$operatorTarget.Path)
            $currentStep='Preflight'
        }
        if ($null -ne $inventory.PSObject.Properties['ProductType'] -and $null -ne $inventory.PSObject.Properties['Version']) {
            $vol=Get-BISFSystemDriveStatus
            Write-BISFLog $logger Info Disk ("System drive={0}; FreeGB={1}; TotalGB={2}; RequiredFreeGB={3}" -f $vol.Drive,$vol.FreeGB,$vol.TotalGB,$config.Preflight.MinimumSystemDriveFreeGB)
            foreach ($service in Get-BISFProfileManagementServices) {
                Write-BISFLog $logger Info ProfileManager ("Name={0}; State={1}; StartMode={2}" -f $service.Name,$service.State,$service.StartMode)
            }
        }
        if ($Mode -ne 'Personalize' -and $config.Cleanup.UserProfiles) {
            $currentStep='UserProfiles'
            $profilePlan=Get-BISFUserProfilePlan $config.Cleanup.ExcludedProfileSIDs -ProtectedPaths $protected
            $targets=@($profilePlan.Entries | Where-Object { $_.Status -eq 'Remove' })
            $blocked=@($profilePlan.Entries | Where-Object { $_.Status -eq 'Blocked' })
            Write-BISFLog $logger Info UserProfiles ("Profile scan: eligible={0}; blocked={1}; total={2}; root={3}" -f $targets.Count,$blocked.Count,$profilePlan.Entries.Count,$profilePlan.Root)
            foreach ($item in $profilePlan.Entries) {
                $level=if ($item.Status -eq 'Blocked') { 'Warning' } else { 'Info' }
                Write-BISFLog $logger $level UserProfiles ("{0}: SID={1}; path={2}; reason={3}" -f $item.Status,$item.SID,$item.LocalPath,$item.Reason)
            }
            $currentStep='Preflight'
        }
        if ($Mode -eq 'Personalize' -and -not $journalStatus.PersonalizationPending -and (Test-BISFCompletion $state $inventory.Identity)) {
            $results.Add([pscustomobject]@{Id='Personalize';Status='Skipped';Message='This clone already completed this preparation generation.'})
            Write-BISFLog $logger Info Personalize 'Skipped: already completed this generation.'
        } elseif ($Mode -eq 'Validate') {
            foreach ($step in $plan) {
                $results.Add([pscustomobject]@{Id=$step.Id;Status='Preview';Message=$step.Description})
                Write-BISFLog $logger Info $step.Id ('Validated plan: '+$step.Description)
            }
            Write-BISFLog $logger Info Validate 'Validation completed. No image operations applied.'
        } else {
            # Ask for all selected actions before beginning; a declined step cannot leave
            # a partially applied plan. WhatIf logs previews but never writes state.
            $declined=$false
            foreach ($step in $plan) {
                if ($step.Id -eq 'CloneGuard') { continue }
                if (-not (Confirm-BISFOperation $PSCmdlet $inventory.Identity.Name $step.Description)) {
                    if (-not $WhatIfPreference) { $declined=$true }
                }
            }
            if ($WhatIfPreference) {
                foreach ($step in $plan) {
                    $results.Add([pscustomobject]@{Id=$step.Id;Status='Preview';Message=$step.Description})
                    Write-BISFLog $logger Info $step.Id ('Preview: '+$step.Description)
                }
            } elseif ($declined) {
                $exitCode=2
                $results.Add([pscustomobject]@{Id='Apply';Status='Skipped';Message='An operation was declined; no changes applied.'})
                Write-BISFLog $logger Warning Apply 'Skipped: one or more operations were declined.'
            } else {
                # Service-state and session checks may change between preview and
                # apply: revalidate before every destructive operation.
                if ($config.Preflight.BlockPendingReboot -and @(Get-BISFPendingRebootReasons).Count -gt 0) {
                    throw 'A reboot is now pending. Preparation cancelled.'
                }
                if ($null -ne $profilePlan -and @($profilePlan.Entries | Where-Object { $_.Status -eq 'Blocked' }).Count -gt 0) {
                    throw 'Refusing profile cleanup while non-exempt profiles are loaded or their lifecycle status is unknown. Log off all other users and retry.'
                }
                if ($Mode -eq 'Prepare') { Test-BISFPreparationProfiles $config }
                $applying=$true
                if ((Get-BISFFileHash -LiteralPath $ConfigPath).Hash -ne $hash) { throw 'Configuration changed during preflight.' }
                $needsState=($Mode -eq 'Prepare' -and (@($plan | ForEach-Object { $_.Id }) -contains 'Lifecycle'))
                if ($needsState -or $Mode -eq 'Personalize' -or (Test-Path -LiteralPath $statePath)) { $journal=Enter-BISFJournal $ScriptRoot $Mode }
                if ($needsState) {
                    $state=New-BISFState $inventory.Identity $hash $config.ConfigurationManager.PrepareIdentityReset
                    $stateTouched=$true
                    Write-BISFState $statePath $state
                } elseif ($Mode -eq 'Prepare' -and (Test-Path -LiteralPath $statePath)) {
                    # An old successful generation must never survive a new preparation.
                    $state=Read-BISFState $statePath
                    $state.Status='Failed'; $state.Completion=$null; $stateTouched=$true
                    Write-BISFState $statePath $state
                }
                foreach ($step in $plan) {
                    if ($step.Id -in @('VDAStop','Shutdown','OperatorFinalize','LogCleanup')) { continue }
                    $currentStep=$step.Id
                    if ($Mode -eq 'Prepare') { Test-BISFPreparationProfiles $config }
                    if ((Get-BISFFileHash -LiteralPath $ConfigPath).Hash -ne $hash) { throw 'Configuration changed during image operations.' }
                    Write-BISFLog $logger Info $step.Id ('Starting: '+$step.Description)
                    switch ($step.Id) {
                        'Servicing' {
                            Invoke-BISFComponentCleanup $config.Servicing.TimeoutMinutes $logger
                        }
                        'RecycleBin' {
                            Invoke-BISFRecycleBinCleanup $logger
                        }
                        'WindowsTemp' {
                            $roots=Get-BISFTempRoots
                            $files=@(Get-BISFCleanupCandidates $roots.WindowsTemp $config.Cleanup.MinimumAgeDays $protected)
                            Remove-BISFTempFiles $files
                        }
                        'CurrentUserTemp' {
                            $roots=Get-BISFTempRoots
                            $files=@(Get-BISFCleanupCandidates $roots.CurrentUserTemp $config.Cleanup.MinimumAgeDays $protected)
                            Remove-BISFTempFiles $files
                        }
                        'UserProfiles' {
                            Invoke-BISFUserProfileCleanup $profilePlan $logger
                        }
                        'ExplorerSettings' { Invoke-BISFExplorerCustomization $config $ScriptRoot $logger }
                        'CMPrepare' { $previousCM=Invoke-BISFCMPrepare }
                        'Lifecycle' {
                            if ($config.Personalization.Enabled) { Register-BISFStartupTask (Join-Path $ScriptRoot 'Invoke-BISF.ps1') $ConfigPath }
                            # Commit eligibility only after operation diagnostics have succeeded.
                        }
                        'CloneGuard' { Test-BISFCloneIdentity $state.Master $inventory.Identity }
                        'CMCloneReset' { Invoke-BISFCMCloneReset }
                        'CMStart' { Start-Service -Name CcmExec -ErrorAction Stop; Wait-BISFService 'Running' }
                        'Complete' {
                            $completionTouched=$true
                            $state.Completion=[pscustomobject]@{Generation=$state.Generation;Identity=$inventory.Identity}
                            # Completion is committed in finalization, after diagnostics.
                        }
                        'Shutdown' { }
                    }
                    if ($step.Id -in @('Lifecycle','Complete')) { Write-BISFLog $logger Info $step.Id 'Ready for state commit.' }
                    else {
                        $results.Add([pscustomobject]@{Id=$step.Id;Status='Completed';Message=$step.Description})
                        Write-BISFLog $logger Info $step.Id 'Completed.'
                    }
                }
                if ($plan.Count -eq 0) { Write-BISFLog $logger Info Prepare 'No image operations enabled. Nothing was sealed or captured.' }
                $currentStep='Finalize'
                if ($Mode -eq 'Prepare') { Test-BISFPreparationProfiles $config }
                if ((Get-BISFFileHash -LiteralPath $ConfigPath).Hash -ne $hash) { throw 'Configuration changed before final sealing.' }
                if ($config.Preflight.BlockPendingReboot -and @(Get-BISFPendingRebootReasons).Count -gt 0) {
                    throw 'Windows servicing now requires a reboot; refusing to finalize or shut down.'
                }
                if ($needsState) { $state.Status='Prepared'; Write-BISFState $statePath $state }
                if ($Mode -eq 'Personalize') { Write-BISFState $statePath $state }
                if (@($plan | ForEach-Object { $_.Id }) -contains 'Shutdown') {
                    $currentStep='Shutdown'
                    Write-BISFLog $logger Info Shutdown 'Requesting shutdown. No further log writes follow an accepted request.'
                    if ($config.Citrix.VDA.StopBeforeShutdown) {
                        $currentStep='VDAStop'
                        # Capture before calling Stop, so a partial stop failure can recover.
                        $previousVDA=Get-BISFVDARunningState
                        Stop-BISFVDA
                        $results.Add([pscustomobject]@{Id='VDAStop';Status='Completed';Message='Desktop Service stopped; startup type unchanged.'})
                    }
                    if ($config.LogCleanup.WindowsEventLogs -or $config.LogCleanup.BISFLogs) {
                        $currentStep='LogCleanup'
                        # This is deliberately the last logging/cleanup step before
                        # requesting shutdown. Security auditing stays intact.
                        Write-BISFLog $logger Info LogCleanup 'Final-stage log hygiene requested. Eligible enabled Administrative/Operational channels will be cleared; Security auditing is preserved.'
                        Invoke-BISFLogCleanup $config $logger
                        $results.Add([pscustomobject]@{Id='LogCleanup';Status='Completed';Message='Selected master log cleanup completed.'})
                    }
                    $currentStep='Shutdown'
                    Stop-Computer -Confirm:$false -ErrorAction Stop
                    $shutdownRequested=$true
                    $results.Add([pscustomobject]@{Id='Shutdown';Status='Completed';Message='Shutdown request accepted.'})
                }
                # This final deletion is the success commit. If shutdown was already
                # accepted and deletion fails, keep the clone blocked; do not try to
                # restore services or write diagnostic files during shutdown.
                if ($null -ne $journal) { Clear-BISFJournal $journal }
                if ($config.Finalization.RemoveOperatorProfile) {
                    $currentStep='OperatorFinalize'
                    # Last fallible file log before the operator may sign out.
                    Write-BISFLog $logger Info OperatorFinalize 'Starting protected SYSTEM task and waiting for readiness before automatic operator sign-out.'
                    $seal=Register-BISFOperatorSeal $ScriptRoot $ConfigPath $config $operatorTarget -ExpectedHash $hash
                    $operatorSignOut=[pscustomobject]@{
                        Generation=$seal.Generation;SID=$operatorTarget.SID;SessionId=$operatorSession.SessionId
                        WorkerProcessId=$seal.WorkerReady.ProcessId;WorkerStartedUtc=$seal.WorkerReady.StartedUtc
                    }
                    $results.Add([pscustomobject]@{Id='OperatorFinalize';Status='Staged';Message='SYSTEM finalizer acknowledged readiness. Automatic sign-out follows release of the preparation lock.'})
                    if ($config.LogCleanup.WindowsEventLogs -or $config.LogCleanup.BISFLogs) {
                        $results.Add([pscustomobject]@{Id='LogCleanup';Status='Staged';Message='Log cleanup deferred to the SYSTEM finalizer after operator sign-out.'})
                    }
                    Write-Host 'BIS-F Local: SYSTEM finalizer ready. Windows sign-out will be requested automatically after preparation returns; shutdown follows successful profile and log cleanup.'
                }
                foreach ($step in $plan) {
                    if ($step.Id -in @('Lifecycle','Complete')) { $results.Add([pscustomobject]@{Id=$step.Id;Status='Completed';Message=$step.Description}) }
                }

            }
        }
    } catch {
        $operatorSignOut=$null
        $errorMessage=$_.Exception.Message
        if ($applying) { $exitCode=2 } else { $exitCode=1 }
        $results.Add([pscustomobject]@{Id=$currentStep;Status='Failed';Message=$errorMessage})
        if ($Mode -eq 'Prepare' -and $stateTouched -and -not $shutdownRequested) {
            try { $state.Status='Failed'; $state.Completion=$null; Write-BISFState $statePath $state }
            catch { Write-Warning "Could not invalidate preparation state: $($_.Exception.Message)" }
        }
        if ($Mode -eq 'Personalize' -and $completionTouched) {
            try { $state.Completion=$null; Write-BISFState $statePath $state }
            catch { Write-Warning "Could not clear clone completion state: $($_.Exception.Message)" }
        }
        if ($null -ne $previousCM -and -not $shutdownRequested) {
            try { Restore-BISFCMService $previousCM }
            catch { Write-Warning "Could not restore CcmExec: $($_.Exception.Message)" }
        }
        if ($null -ne $previousVDA -and -not $shutdownRequested) {
            try { Restore-BISFVDA $previousVDA }
            catch { Write-Warning "Could not restore Citrix Desktop Service: $($_.Exception.Message)" }
        }
        if ($shutdownRequested) { Write-Warning "Shutdown was accepted, but finalization failed; the incomplete-run journal remains. $errorMessage" }
        else {
            try { Write-BISFLog $logger Error $currentStep $errorMessage }
            catch { Write-Warning "Log write failed. Original error: $errorMessage" }
        }
    } finally {
        Close-BISFLogger $logger
        Exit-BISFLock $lock
    }
    Write-Host ("BIS-F Local: Mode={0}, ExitCode={1}, Completed={2}, Failed={3}" -f $Mode,$exitCode,@($results | Where-Object Status -eq 'Completed').Count,@($results | Where-Object Status -eq 'Failed').Count)
    [pscustomobject]@{ExitCode=$exitCode;Mode=$Mode;Results=$results.ToArray();Error=$errorMessage;Citrix=$citrix;OperatorSignOut=$operatorSignOut}
}

